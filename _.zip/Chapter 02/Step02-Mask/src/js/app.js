'use strict';
angular.module('myApp', ['myApp.controllers', 'ui.utils']);
