'use strict';
angular.module('myApp.controllers', []).controller('NgAnimateCtrl', function ($scope) {

});
