'use strict';
angular.module('myApp.controllers', []).controller('uiModulesCtrl', function ($scope, $timeout) {



});
