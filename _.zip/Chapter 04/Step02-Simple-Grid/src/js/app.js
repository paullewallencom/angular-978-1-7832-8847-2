'use strict';

angular.module('myApp', ['ngGrid', 'myApp.controllers', 'myApp.filters', 'myApp.services']);
