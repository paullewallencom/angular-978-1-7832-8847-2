'use strict';
angular.module("myApp.filters", []);
