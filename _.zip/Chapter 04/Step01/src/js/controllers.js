'use strict';
angular.module('myApp.controllers', []).controller('NgGridCtrl', function ($scope) {

});
