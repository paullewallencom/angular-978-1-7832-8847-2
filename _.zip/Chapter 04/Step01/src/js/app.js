'use strict';

angular.module('myApp', ['myApp.controllers', 'myApp.filters']);
