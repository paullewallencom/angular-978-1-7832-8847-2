'use strict';
describe('controller specs', function () {
    beforeEach(module('myApp.filters'));

});
