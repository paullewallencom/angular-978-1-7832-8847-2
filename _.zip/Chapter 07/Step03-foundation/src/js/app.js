'use strict';

angular.module('myApp', []).run(function($document) {
  $document.foundation();
});
