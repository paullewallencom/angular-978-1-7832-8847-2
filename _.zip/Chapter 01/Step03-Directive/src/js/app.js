'use strict';

/** app level module which depends on services and controllers */
angular.module('myApp', ['myApp.controllers', 'myApp.directives']);