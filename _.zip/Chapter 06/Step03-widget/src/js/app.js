'use strict';

angular.module('myApp', ['myApp.directives']);
