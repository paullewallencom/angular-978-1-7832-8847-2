'use strict';

angular.module('myApp', ['kendo.directives', 'myApp.controllers']);
